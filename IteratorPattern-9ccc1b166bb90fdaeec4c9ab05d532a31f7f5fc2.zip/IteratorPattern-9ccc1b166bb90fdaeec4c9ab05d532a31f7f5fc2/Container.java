package br.com.aragy.iterator;

public interface Container {
	public Iterator getIterator();  
}
