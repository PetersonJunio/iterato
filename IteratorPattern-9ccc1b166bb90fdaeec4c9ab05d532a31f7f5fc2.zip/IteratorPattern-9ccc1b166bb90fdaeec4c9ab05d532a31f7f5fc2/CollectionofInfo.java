package br.com.aragy.iterator;

public class CollectionofInfo implements  Container {

	public int age[] = { 21, 38, 46, 967, 99 };
	public String address[] = { "C�u", "Coordena��o", "ProReitoria", "Trabalho", "Campo Grande" };
	public String designation[] = { "Java Programmer and Content Writer", "CEO", 
			"Professorora", "Manager","Escola/Faculdade" };
	
	public Iterator getIterator() {
		// TODO Auto-generated method stub
		return null;
	}

}

